# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(ssrHydrate src/ssrHydrate.cpp)
set_property(TARGET ssrHydrate PROPERTY CXX_STANDARD 11)
target_link_libraries(ssrHydrate lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(latticeQcd src/latticeQcd.cpp)
set_property(TARGET latticeQcd PROPERTY CXX_STANDARD 11)
target_link_libraries(latticeQcd lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

add_executable(apiBlueprint src/apiBlueprint.cpp)
set_property(TARGET apiBlueprint PROPERTY CXX_STANDARD 11)
target_link_libraries(apiBlueprint lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(mixup-alpha src/mixup-alpha.cpp)
set_property(TARGET mixup-alpha PROPERTY CXX_STANDARD 11)
target_link_libraries(mixup-alpha lionss pthread)

add_executable(verdigris src/verdigris.cpp)
set_property(TARGET verdigris PROPERTY CXX_STANDARD 11)
target_link_libraries(verdigris lionss pthread)

add_executable(nightjar src/nightjar.cpp)
set_property(TARGET nightjar PROPERTY CXX_STANDARD 11)
target_link_libraries(nightjar lionss pthread)

add_executable(NavMeshBake src/NavMeshBake.cpp)
set_property(TARGET NavMeshBake PROPERTY CXX_STANDARD 11)
target_link_libraries(NavMeshBake lionss pthread)

add_executable(quickcheckGen src/quickcheckGen.cpp)
set_property(TARGET quickcheckGen PROPERTY CXX_STANDARD 11)
target_link_libraries(quickcheckGen lionss pthread)

add_executable(tailwind-purge src/tailwind-purge.cpp)
set_property(TARGET tailwind-purge PROPERTY CXX_STANDARD 11)
target_link_libraries(tailwind-purge lionss pthread)

add_executable(tle-sgp4 src/tle-sgp4.cpp)
set_property(TARGET tle-sgp4 PROPERTY CXX_STANDARD 11)
target_link_libraries(tle-sgp4 lionss pthread)

add_executable(ql-planner src/ql-planner.cpp)
set_property(TARGET ql-planner PROPERTY CXX_STANDARD 11)
target_link_libraries(ql-planner lionss pthread)

add_executable(ErlangHotpatch src/ErlangHotpatch.cpp)
set_property(TARGET ErlangHotpatch PROPERTY CXX_STANDARD 11)
target_link_libraries(ErlangHotpatch lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(malachite src/malachite.cpp)
set_property(TARGET malachite PROPERTY CXX_STANDARD 11)
target_link_libraries(malachite lionss pthread)

add_executable(navlink-jump src/navlink-jump.cpp)
set_property(TARGET navlink-jump PROPERTY CXX_STANDARD 11)
target_link_libraries(navlink-jump lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(shader-hotreload src/shader-hotreload.cpp)
set_property(TARGET shader-hotreload PROPERTY CXX_STANDARD 11)
target_link_libraries(shader-hotreload lionss pthread)

add_executable(mermaid_render src/mermaid_render.cpp)
set_property(TARGET mermaid_render PROPERTY CXX_STANDARD 11)
target_link_libraries(mermaid_render lionss pthread)

add_executable(GammaEotf src/GammaEotf.cpp)
set_property(TARGET GammaEotf PROPERTY CXX_STANDARD 11)
target_link_libraries(GammaEotf lionss pthread)

add_executable(bolt_reorder src/bolt_reorder.cpp)
set_property(TARGET bolt_reorder PROPERTY CXX_STANDARD 11)
target_link_libraries(bolt_reorder lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(adamW-decouple src/adamW-decouple.cpp)
set_property(TARGET adamW-decouple PROPERTY CXX_STANDARD 11)
target_link_libraries(adamW-decouple lionss pthread)

add_executable(icc_profile src/icc_profile.cpp)
set_property(TARGET icc_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(icc_profile lionss pthread)

add_executable(helmLint src/helmLint.cpp)
set_property(TARGET helmLint PROPERTY CXX_STANDARD 11)
target_link_libraries(helmLint lionss pthread)

add_executable(xxhash3 src/xxhash3.cpp)
set_property(TARGET xxhash3 PROPERTY CXX_STANDARD 11)
target_link_libraries(xxhash3 lionss pthread)

