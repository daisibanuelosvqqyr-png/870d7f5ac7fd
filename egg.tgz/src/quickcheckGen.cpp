// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Generate random cases"); }
int main(){
  announce();
  return lionss_run_workload("quickcheckGen");
}
