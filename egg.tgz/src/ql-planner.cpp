// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Plan logical query"); }
int main(){
  announce();
  return lionss_run_workload("ql-planner");
}
