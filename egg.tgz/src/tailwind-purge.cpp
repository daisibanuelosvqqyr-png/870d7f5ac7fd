// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Purge unused classes\n", stdout);
  return lionss_run_workload("tailwind-purge");
}
